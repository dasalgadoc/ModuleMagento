<?php

namespace Magento\Catalog\Model\Product\Price;

class BasePrice extends \Magento\Catalog\Model\Products\Price\BasePrice
{


    public function getPrice()
    {
        return 0;
    }
}
